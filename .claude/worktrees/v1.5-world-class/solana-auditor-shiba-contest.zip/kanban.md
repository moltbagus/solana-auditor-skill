# Kanban — Solana Auditor Shiba Skill

> **Project Kanban Board**
> _World-Class Edition — v1.5.0_
> Last updated: 2026-06-25 12:00

---

## ⏱️ DEADLINE COUNTDOWN

```
SHIP BY: 2026-06-27 12:00 (48 hours from start)
TIME REMAINING: 44h 48m
STATUS: ⏳ MAIN THREAD — All agents DONE
```

---

## Workflow

```
Backlog → To Do → In Progress → Review → Done
```

---

## Columns

### 🟢 Done (v1.0–v1.4.0 FINAL)

| Task | Phase | Version |
|------|-------|---------|
| 6-phase audit lifecycle (Recon → Remediation) | Core | v1.0.0 |
| 6 slash commands (`/audit`, `/audit-quick`, `/audit-resume`, etc.) | Core | v1.4.0 |
| 17 path-scoped rules with CWE refs | Core | v1.4.0 |
| 4 specialist agents with I/O contracts | Core | v1.0.0 |
| Dual example fixtures (vault 10 + token-extensions 6 VULN) | Core | v1.3.0 |
| Real Token-2022 fixture (spl_token_2022, VULN-17) | Core | v1.4.0 |
| CVSS 3.1 scoring with math verification | Core | v1.2.0 |
| CI pipeline (3 jobs: integrity + build + lint) | Core | v1.0.0 |
| PoC templates (Anchor, TypeScript, Manual) | Polish | v1.1.0 |
| 62 integrity checks passing | Core | v1.4.0 |
| Install script + skill path verification | Core | v1.2.3 |
| Agent YAML frontmatter for all 4 agents | Polish | v1.2.3 |
| SDD documents (PRD, Spec, Kanban, Learnings) | Docs | v1.3.0 |
| Property-based testing harness (19 fuzz tests) | Testing | v1.3.0 |
| Token-2022 fixture (VULN-11 through VULN-16) | Content | v1.3.0 |
| Brazilian Portuguese glossary | Content | v1.3.0 |
| Demo script (`bash demo.sh`) | Polish | v1.3.0 |
| Flash loan attack Rule 13 (CRITICAL) | Security | v1.4.0 |
| Reentrancy guard Rule 14 (CRITICAL) | Security | v1.4.0 |
| remaining_accounts Rule 15 (CRITICAL, Raydium) | Security | v1.4.0 |
| Discriminator collision Rule 16 (CRITICAL) | Security | v1.4.0 |
| AccountLoader Rule 17 (HIGH, Mango) | Security | v1.4.0 |
| SARIF export for GitHub Code Scanning | Integrations | v1.4.0 |
| Concurrent-run lock file protection | Operations | v1.4.0 |

### 🔵 In Progress (v1.6 World-Class Sprint)

| Task | Agent ID | Status | Done |
|------|----------|--------|------|
| Gap analysis: rules, tooling, completeness | ~~a5fd4ca3~~ | ✅ **DONE** | ✅ |
| Rules completeness analysis | ~~aba2373b~~ | ✅ **DONE** | ✅ |
| Tooling gap analysis | ~~a243ae4e~~ | ✅ **DONE** | ✅ |
| GitHub Actions CI workflow | ~~a77c6323~~ | 🔄 Running | - |
| semgrep Solana ruleset | ~~ad0d7f23~~ | 🔄 Running | - |
| Protocol fingerprinting DB | ~~a2c0e129~~ | 🔄 Running | - |
| Update commands/ for new agent | P1 | After agent done |
| Update install.sh for new files | P1 | After SKILL.md done |
| Demo script update | P1 | After new features done |
| Git push + tag v1.5.0 | P0 | After all above |

---

## Sprint 5 — World-Class (Active)

### Goal: Ship v1.5 by 2026-06-27 12:00

| Task | Owner | Status | Hours |
|------|-------|--------|-------|
| Tier 2 runtime verification (Phase 2B) | Agent-1 | 🔄 | 6 |
| Cargo-audit + Helius API (Phase 1) | Agent-2 | 🔄 | 4 |
| 9 new security rules (18-26) | Agent-3 | 🔄 | 4 |
| Cross-Program Analysis Agent | Agent-4 | 🔄 | 6 |
| SPEC.md + PRD.md v1.5 | Agent-5 | 🔄 | 2 |
| Integrity test updates | Main | ⏳ | 2 |
| Full test suite + CI | Main | ⏳ | 2 |
| SKILL.md + commands update | Main | ⏳ | 2 |
| Demo + install update | Main | ⏳ | 1 |
| Final review + push | Main | ⏳ | 1 |

**Total: ~30 hours (5 agents + main thread, 48hr deadline with buffer)**

---

## Sprint 6 — v1.6 Automation Sprint

| Task | Owner | Status | Hours |
|------|-------|--------|-------|
| Gap analysis | Agents | ✅ | 2 |
| GitHub Actions CI workflow | Agent | 🔄 | 3 |
| semgrep Solana ruleset | Agent | 🔄 | 4 |
| Protocol fingerprinting DB | Agent | 🔄 | 3 |
| Integrity tests | Main | ⏳ | 2 |
| Final push | Main | ⏳ | 1 |

---

## Time Log

| Time | Event | Remaining |
|------|-------|-----------|
| 2026-06-25 12:00 | Sprint started — 5 agents launched | 48h 0m |
| 2026-06-25 12:26 | ✅ Cross-Program Agent DONE (627 lines) | 47h 34m |
| 2026-06-25 12:31 | ✅ Rules 18-26 DONE (9 new rules added) | 47h 29m |
| 2026-06-25 13:27 | ✅ Tier 2 Runtime DONE (skill/02B, 1070 lines) | 46h 33m |
| 2026-06-25 13:36 | ✅ SPEC.md + PRD.md DONE (v1.5, 6 agents, 26 rules) | 46h 24m |
| 2026-06-25 15:12 | ✅ Cargo-audit + CPI graph DONE (skill/01 + scripts/) | 44h 48m |
| 2026-06-25 15:30 | ✅ SKILL.md DONE (v1.5, 7 phases, 6 agents) | 44h 30m |
| 2026-06-25 16:00 | ✅ Commands DONE (all 6 updated for v1.5) | 44h 0m |
| 2026-06-25 16:30 | ✅ Integrity tests DONE (checks 22-30 for v1.5) | 43h 30m |
| 2026-06-25 16:30 | 🟡 AWAITING: `bash tests/test-skill-integrity.sh` | user needs to run |
| 2026-06-26 23:03 | ✅ SHIPPED — v1.5.0 committed (326a4d3), tagged, pushed to main | 0h |

---

## Velocity Tracking (v1.5 Target)

| Metric | v1.4 FINAL | v1.5 Target | Delta |
|--------|------------|-------------|-------|
| Integrity checks | 62 | **70+** | +8 |
| Security rules | 17 | **26** | +9 |
| Specialist agents | 4 | **6** | +2 |
| Phases | 6 | **7** | +1 |
| Commands | 6 | **6** | - |
| Property-based tests | 19 | **25+** | +6 |
| Two-tier execution | No | **Yes** | +1 |
| CPI surface analysis | No | **Yes** | +1 |
| Cross-program agent | No | **Yes** | +1 |
| Cargo-audit integration | No | **Yes** | +1 |
| Helius API integration | No | **Yes** | +1 |

---

## What's New in v1.5 (World-Class)

### New Rules (18-26)
- Rule 18: Borsh Deserialization Panic
- Rule 19: Anchor verify/address Constraint Bypass (0.30+)
- Rule 20: Token-2022 Extension Ordering
- Rule 21: CPI Callback Reentrancy
- Rule 22: init_if_needed + close Race
- Rule 23: Memo Program CPI Injection
- Rule 24: remaining_accounts Count Mismatch
- Rule 25: Versioned Transaction LUT Manipulation
- Rule 26: Cross-Program Flash Loan Composition

### New Agents
- **Cross-Program Agent**: CPI graph traversal, flash loan path detection, callback reentrancy analysis

### New Phases
- **Phase 2B**: Runtime Verification (anchor test, banks_client fuzzing, QED 2A fallback)

### New Integrations
- **cargo-audit**: Supply chain CVE scanning
- **Helius API**: On-chain program state analysis
- **CPI surface graph**: Automated program dependency extraction

### Execution Model
- **Tier 1** (no toolchain): SAST only — semgrep, ripgrep, 26 rules
- **Tier 2** (full toolchain): SAST + runtime + formal verification