# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

# Solana Auditor Shiba Skill

Submission-grade Solana security auditor — 6-phase lifecycle, 17 path-scoped rules, 4 specialist agents, compile-verified example fixture.

**Extends**: solana-dev-skill  
**Agents**: orchestrator, auditor, formal-verifier, report-writer, cross-program-agent  
**Commands**: `/audit`, `/audit-quick`, `/audit-resume`, `/audit-report`, `/audit-poc`, `/audit-findings`, `/audit-history`, `/audit-pr`
**Automation**: pre-commit hook (`scripts/pre-commit-audit.sh`), PR auditing (`/audit-pr`), audit history DB (`scripts/audit-history.sh`), inline fix suggestions (`scripts/audit-fix-suggestions.py`), SARIF export (`scripts/export-sarif.py`)


---

## Commands

```bash
# Install skill
./install.sh -y

# Demo (no Solana toolchain needed)
bash demo.sh

# Integrity checks (62 verification points)
bash tests/test-skill-integrity.sh

# Single category
bash tests/test-skill-integrity.sh 2>&1 | grep "Check 10"

# Fuzz tests (19 Hypothesis strategies)
python3 -m pytest tests/fuzz/ -v

# Single fuzz test
python3 -m pytest tests/fuzz/test_properties.py::test_cvss_vector_roundtrip -v
```

---

## Architecture

```
skill/SKILL.md (hub)
    ├─ skill/01-recon.md          # Phase 1: Attack surface
    ├─ skill/02-static-analysis.md # Phase 2: Anchor/Token/CPI checks
    ├─ skill/03-formal-verification.md  # Phase 3: QED 2A invariants
    ├─ skill/04-findings-triage.md      # Phase 4: CVSS scoring
    ├─ skill/05-report-generation.md     # Phase 5: Report output
    └─ skill/06-remediation.md          # Phase 6: Fix guidance

agents/
    ├─ orchestrator.md      # Entry point, routes to specialists
    ├─ auditor.md           # Primary audit execution
    ├─ formal-verifier.md    # Invariant proofs
    └─ report-writer.md     # Structured findings → report

commands/
    ├─ audit.md, audit-quick.md, audit-resume.md
    ├─ audit-report.md, audit-poc.md, audit-findings.md

rules/audit.rules     # 17 path-scoped security rules
```

### Agent Handoff Protocol

Orchestrator → Specialist:
```json
{"agent": "auditor", "phase": 2, "input_artifacts": [...], "context": "..."}
```

Specialist → Orchestrator:
```json
{"status": "ok", "outputs": [...], "next_agent": "formal-verifier", "notes": "..."}
```

---

## 17 Security Rules (Path-Scoped)

Rules auto-activate when editing matching file patterns. No command invocation needed.

| Rule | Triggers | Catches | Default |
|------|----------|---------|---------|
| 1 | `programs/**/src/lib.rs` | Privileged instruction surface | HIGH |
| 2 | `programs/**/*.rs` | Missing discriminator/owner/init | HIGH→CRIT |
| 3 | `programs/**/*.rs` | Hardcoded/non-canonical PDA bump | MED→CRIT |
| 4 | `programs/**/*.rs` | CPI escalation, unverified program ID | HIGH→CRIT |
| 5 | `programs/**/*.rs` + `Cargo.toml` | SPL vs Token-2022 mismatch | HIGH |
| 6 | `programs/**/*.rs` | Integer overflow on u64 amounts | MEDIUM |
| 7 | `programs/**/*.rs` | Lamport drain via wrong close target | CRITICAL |
| 8 | `programs/**/*.rs` | Unsigned privileged action | CRITICAL |
| 9 | `Anchor.toml` | Upgrade authority surface | MEDIUM |
| 10 | `programs/**/src/error.rs` | panic!, missing error mapping | LOW |
| 11 | `programs/**/src/state.rs` | Reinit without discriminator | CRITICAL |
| 12 | `programs/**/*.rs` | Rent exemption breaking | MEDIUM |
| 13 | `programs/**/*.rs` | Flash loan oracle manipulation | CRITICAL |
| 14 | `programs/**/*.rs` | Reentrancy (CEI violation) | CRITICAL |
| 15 | `programs/**/*.rs` | missing remaining_accounts validation | CRITICAL |
| 16 | `programs/**/*.rs` | Discriminator collision | CRITICAL |
| 17 | `programs/**/*.rs` | AccountLoader without owner check | HIGH |

Each rule cites CWE + real exploit references (Wormhole, Cashio, Crema, Mango, etc.).

---

## Critical Constraints

| Constraint | Rationale |
|------------|-----------|
| **PoC consent required** | Explicit user consent before executing any exploit code |
| **No auto-apply fixes** | Operator reviews and applies remediation |
| **No live exploit execution** | Consent gate enforced; mainnet requires owner authorization |
| **CVSS math verified** | `severity_counts.py:check_cvss_math()` recomputes from vectors |
| **VULN ↔ findings 1:1** | Every `// VULN-XX:` tag must have matching finding |

### Absolute Prohibitions
1. Never auto-apply security fixes without operator review
2. Never execute PoCs without explicit typed consent ("YES" or equivalent)
3. Never commit secrets/private keys to audit scope files
4. Never audit mainnet program without double-confirmation of program owner identity
5. Never write live exploit code in audit reports — reference PoC path only

---

## Severity Scale

| Level | Meaning | Examples |
|-------|---------|----------|
| CRITICAL | Total fund loss / authority bypass | `invoke` without signer, wrong close target |
| HIGH | Significant loss / major logic flaw | Integer overflow, CPI escalation |
| MEDIUM | Indirect loss path | Missing owner check, hardcoded bump |
| LOW | Minor / best practice | `panic!`, missing error codes |
| INFO | Documentation / code quality | Unnecessary complexity |

---

## Output Schema

Example fixture structure (`examples/sample-vulnerable-program/`):
```
programs/vault/src/lib.rs         # 10 VULN tags (VULN-01 to VULN-10)
programs/token-extensions/src/lib.rs  # 6 VULN tags (VULN-11 to VULN-16)
audit-output/
   ├─ findings.json              # Structured findings (6 total)
   ├─ AUDIT_REPORT.md            # Human-readable report
   ├─ quick-scan-results.md      # /audit-quick output
   └─ methodology-trace.md       # Phase-to-finding mapping
```

findings.json schema:
```json
{
  "id": "CRIT-01",
  "severity": "CRITICAL",
  "cvss": 9.8,
  "cvss_vector": "CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:H/I:H/A:H",
  "cwe": "CWE-306",
  "title": "<finding-title>",
  "location": {"file": "path.rs", "line": 42, "function": "admin_withdraw"},
  "description": "<technical-description>",
  "impact": "<concrete-impact>",
  "recommendation": "<fix-guidance>",
  "poc_status": "pending | confirmed | verified | fixed | disproved",
  "rule_caught": "Rule 8",
  "status": "Open"
}
```

---

## File Contracts

| File | Contract |
|------|----------|
| `tests/test-skill-integrity.sh` | Single source of truth for fixture paths (`VAULT_SRC`, `TOKEN_SRC`) |
| `tests/severity_counts.py` | Validates findings.json → AUDIT_REPORT.md consistency + CVSS math |
| `rules/audit.rules` | 1:1 mapping: every rule → one `**References:**` block with CWE URL |
| `skill/0N-*.md` | Filename prefix must match `# Phase N:` heading |

---

## CVSS Scoring

All scores are **mathematically verified** from vectors using CVSS 3.1 formula:
```python
# In tests/severity_counts.py
check_cvss_math()  # Recomputes score from vector, flags mismatch
```

Example vector → score mapping:
- `CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:H/I:H/A:H` → **9.8** (CRITICAL)

---

## Tool Requirements

- `anchor-cli` 0.31.1 (example fixture built against this version)
- `solana-cli` 2.x
- `rustc` 1.75+
- QED 2A (optional — phase 3 formal verification)

Local toolchain setup:
```bash
curl --proto '=https' --tlsv1.2 -sSf https://sh.rustup.rs | sh -s -- -y --default-toolchain stable
sh -c "$(curl -sSfL https://release.anza.xyz/stable/install)"
cargo install --git https://github.com/coral-xyz/anchor --tag v0.31.1 anchor-cli --locked
```
