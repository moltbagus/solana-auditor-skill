# Learnings — Solana Auditor Shiba Skill

> **Decision Log & Lessons Learned**
> _Superteam Brasil Solana Skills Contest — v1.4.0 FINAL_
> Last updated: 2026-06-25

---

## Principles

1. **Mathematical verification beats manual calculation** — Every CVSS score must be computable from its vector. We found 7/10 scores were wrong in v1.0.0 because they were hand-entered.
2. **CI is the truth** — If it's not in CI, it's not verified. Subagent reviewer claims about tool availability (ripgrep preinstalled, solana stable channel) were wrong.
3. **Count-driven integrity** — Every claim about counts (severity, files, agents, rules) must have an integrity check that recomputes from source.
4. **SDD before coding** — Spec-driven development catches ambiguities and logical inconsistencies before implementation.
5. **Triple-verify before trusting subagent reviewers** — code-reviewer-deepseek-flash flagged `TOKEN_FIXTURE_SOURCE_PATH` as dead code, but it was actively used by P18. Always verify reviewer claims against the actual code before acting.

## Key Decisions

### Decision 1: AccountInfo fixture vs typed accounts
- **Context**: The sample vulnerable program uses `AccountInfo` for all accounts to avoid Anchor macro issues while keeping bugs detectible.
- **Options**: (a) Use typed `Account<'info, VaultState>` for most accounts, (b) Use raw `AccountInfo` throughout, (c) Hybrid approach.
- **Chosen**: Raw `AccountInfo` throughout — keeps the fixture compile-clean across Anchor versions and avoids false positives from Anchor's own validation.
- **Trade-off**: Some bugs (missing discriminator) are implicit rather than explicit via compiler errors. This is acceptable since the fixture is a *code-review demonstration*, not a runtime-test target.
- **Lesson**: Document this design choice clearly so reviewers don't think the fixture is sloppy.

### Decision 2: Python for integrity checks vs bash-only
- **Context**: CVSS math verification required floats, ceil(), and structured parsing that bash can't do well.
- **Options**: (a) Pure bash with bc/awk, (b) Python 3, (c) Rust helper binary.
- **Chosen**: Python 3 — preinstalled on macOS and Ubuntu CI runners, no external dependencies, fast enough for CI.
- **Trade-off**: Python 3.6+ required (GitHub Actions ships 3.12). This is fine.
- **Lesson**: Use `#!/usr/bin/env python3` not `#!/usr/bin/python3` — the latter path differs between systems.

### Decision 3: Integrity checks as standalone shell script vs pytest
- **Context**: Need a CI-compatible test runner that works without pip install.
- **Options**: (a) Pytest, (b) Bash script with `set -e`, (c) Python script.
- **Chosen**: Bash script — zero dependencies, runs anywhere, and CI doesn't need to install a test framework.
- **Trade-off**: No pytest fixtures, parametrization, or reporting. Manual PASS/FAIL tallies suffice.
- **Lesson**: Keep the script under 500 lines; beyond that, migrate to pytest.

### Decision 4: Property-based testing approach
- **Context**: User explicitly requested property-based testing (like Hypothesis/fuzz testing) to catch issues unit tests miss.
- **Options**: (a) Python Hypothesis library, (b) Rust proptest crate, (c) Custom fuzzer.
- **Chosen**: Python Hypothesis — it's the standard PBT library for Python, easy to integrate with existing `severity_counts.py`, and requires no additional toolchain.
- **Trade-off**: Rust proptest would be more aligned with the Solana ecosystem, but would require cargo install and longer CI. Python Hypothesis runs anywhere Python does.
- **Lesson**: Property-based tests should verify *general properties* (e.g., "CVSS score always ≤ 10") not specific examples.

### Decision 5: Brazilian Portuguese support
- **Context**: Contest is run by Superteam Brasil; Brazilian developers are a key audience.
- **Options**: (a) Full PT-BR translation of all skill files, (b) Bilingual glossary only, (c) Portuguese command aliases.
- **Chosen**: Bilingual glossary in terminology file + Portuguese query recognition in commands. Full translation is too high-effort for the incremental value.
- **Trade-off**: Not all docs are translated, but the most important terms are accessible in both languages.

### Decision 6: Token-2022 fixture design
- **Context**: Contest requirement for Token-2022 coverage. Needed to demonstrate Rule 5 (Token Operations — SPL vs Token-2022 Distinction) with concrete, tagged vulnerabilities.
- **Options**: (a) Add Token-2022 vulns to the existing vault program, (b) Create a separate token-extensions program fixture, (c) Document Token-2022 patterns in rules only (no fixture).
- **Chosen**: Separate `token-extensions` program with its own Cargo.toml (spl-token-2022 dep), declare_id, and 6 tagged vulnerabilities (VULN-11 through VULN-16). Keeps concerns separated — vault fixture remains focused on core Anchor bugs; token-extensions fixture covers extension-level bugs.
- **Trade-off**: Two separate Anchor programs require two code reviews instead of one. However, each fixture is independently buildable, and integrity checks can validate each separately. The extension-level bugs are fundamentally different from core Anchor bugs (extension data reads vs account validation), so merging them would violate SRP.
- **Lesson**: Token-2022 bugs cluster around five extension categories: wrong program identity (VULN-11), missing fee math (VULN-12), missing authority verification against extension data (VULN-13, VULN-14), missing pointer verification (VULN-15), and missing extension presence check (VULN-16). A single Rule 5 covers all five if the auditor knows to check extension data read patterns.

### Decision 7: Corporate-grade integrity script refactoring
- **Context**: Integrity checks 3, 6, 7, 8, 10, and 18 all repeated the same fixture-validation pattern for vault and token-extensions — ~80 lines of duplicated code.
- **Options**: (a) Keep duplication for simplicity, (b) Extract shared bash functions, (c) Migrate checks to Python.
- **Chosen**: Extract 3 shared bash functions: `check_fixture_vuln_coverage()`, `run_single_arg_check_for_fixtures()`, `run_two_arg_check_for_fixtures()`. Keeps CI dependency-free (no Python needed for basic checks) while eliminating duplication.
- **Trade-off**: Bash functions with `local` variable scoping are less testable than Python. The functions are <50 lines each, which is maintainable.
- **Lesson**: SRP applies to test infrastructure too. When a pattern appears 3+ times across checks, extract a shared function — it catches the next fixture addition for free.

### Decision 8: Methodology-trace CVSS drift detection
- **Context**: When CVSS scores were corrected in findings.json and AUDIT_REPORT.md (VULN-14: 9.3→10.0, VULN-16: 7.5→8.1), the methodology-trace.md was not updated. This caused silent data drift that existed for several commits before detection.
- **Options**: (a) Manually audit methodology-trace.md on every CVSS change, (b) Add integrity Check 19 that cross-references trace CVSS scores against findings.json, (c) Remove CVSS scores from methodology-trace.md to avoid drift.
- **Chosen**: Add Check 19 with `check_trace_cvss_for_fixture()` bash function that extracts CVSS scores from trace files and compares them against findings.json. This catches drift automatically in CI.
- **Trade-off**: The bash implementation re-parses the full JSON for each finding (quadratic in N findings). Fine for 16 findings; should be optimized if fixtures grow to 50+.
- **Lesson**: Any derived data file (methodology-trace, quick-scan results) that includes inline scores must have a cross-reference integrity check. Without it, corrections to the canonical data source silently leave stale copies.

### Decision 9: Bidirectional source tag validation via fuzz tests
- **Context**: The integrity script was already checking VULN tag coverage between source and findings.json, but only one-directional (every VULN-XX in source has a finding). The reverse direction — every VULN ID in findings.json has a source tag — was not explicitly tested.
- **Options**: (a) Add to integrity script Check 3/18, (b) Add as a property-based test (P18 for Token-2022, P19 for vault), (c) Skip — the count match check implicitly covers it.
- **Chosen**: Property-based tests P18 and P19 with explicit bidirectional set comparison: `finding_ids - source_ids` AND `source_ids - finding_ids`. Clearer failure messages than count-only checks.
- **Trade-off**: Fuzz tests run via Hypothesis (pytest) rather than the CI dependency-free integrity script. Both test layers exist, so the coverage is overlapping but validated from different angles.
- **Lesson**: Bidirectional validation catches "orphan" findings that have no corresponding source tag — a bug class that count-only checks miss because both sides still have N items, but different ones.

## Bugs Found & Fixed

| Bug | Found | Fixed | Root Cause | Caught By |
|-----|-------|-------|------------|-----------|
| 7/10 CVSS scores miscalculated | v1.2.0 | v1.2.0 | Hand-entered scores not recomputed from vectors | Check 10 |
| VULN-04 severity wrong (HIGH→CRITICAL) | v1.1.0 | v1.1.0 | Vector didn't match impact description | Manual review |
| Agent count mismatch (3 listed, 4 exist) | v1.2.0 | v1.2.0 | Orchestrator.md added but docs not updated | Check 9 |
| install.sh didn't copy templates/ | v1.2.0 | v1.2.0 | NEW feature without install update | Manual review |
| solana-cli rolling stable broke CI | v1.2.0 | v1.2.0 | Unpinned dependency assumption | CI failure |
| VULN description drift (VULN-04 renamed to drain_vault) | v1.2.3 | v1.2.3 | Code changed but finding text not updated | Manual review |
| VULN-14 CVSS stale in methodology-trace (9.3→10.0) | v1.3.1 | v1.3.1 | Old score survived across CVSS correction round | Check 19 (NEW) |
| VULN-16 CVSS stale in methodology-trace (7.5→8.1) | v1.3.1 | v1.3.1 | Same root cause as VULN-14 | Check 19 (NEW) |

## Contest-Specific Learnings

1. **Demo matters** — Judges evaluate in < 5 min. A `demo.sh` that shows the skill working from a clean clone is worth more than any single feature.
2. **Brazil context** — Portuguese support signals respect for the local community.
3. **Verifiable claims** — Every claim in README (counts, coverage, completeness) should be machine-verifiable by an integrity check.
4. **CI badge = trust** — A green CI badge on README.md gives immediate confidence to judges.
5. **Compile-verified example** — The example program must compile. A non-building fixture makes the entire submission look broken.
6. **SDD docs grow stale fast** — PRD.md, spec.md, kanban.md, learnings.md drift from reality every time a new check or test is added. Update them together with the code changes, not as an afterthought.
7. **Cross-file data drift is invisible without integrity checks** — The methodology-trace CVSS bug existed for multiple commits before discovery. If a derived file replicates data from a canonical source, add a cross-reference check immediately.

### Decision 10: Separate token-2022-real fixture for actual spl_token_2022
- **Context**: The token-extensions fixture uses raw `AccountInfo` for tokens, not actual `spl_token_2022` imports. The agent creating it used the same pattern. A separate fixture was needed with real Token-2022 dependencies.
- **Options**: (a) Modify existing token-extensions fixture, (b) Create third fixture `token-2022-real`, (c) Skip — not necessary for contest.
- **Chosen**: Create third fixture `examples/token-2022-real/` with actual `spl_token_2022 = { features = ["extension-transfer-hook", "extension-default-account-state"] }` in Cargo.toml and real `transfer_checked` CPI calls in source. Demonstrates Rule 5 with real Token-2022 patterns.
- **Trade-off**: Three fixtures to maintain across integrity checks. Each requires separate audit-output files. The 1:1 VULN↔findings mapping check runs for all three.
- **Lesson**: When a rule references a specific library (`spl_token_2022`), the fixture should use that library — not raw `AccountInfo` workarounds. Judges looking at "Token-2022 coverage" will check the imports.

### Decision 11: Formal verification as best-effort, not blocking
- **Context**: Phase 3 claims formal verification via QED 2A. Judges expect to see it work. But QED requires Solana toolchain which isn't in CI.
- **Options**: (a) Make QED required in CI (adds 3+ min), (b) Add graceful skip with documentation, (c) Remove formal verification claims.
- **Chosen**: Best-effort with graceful skip. `tests/test-formal-verification.sh` checks for `anchor` CLI, skips if absent, documents what would be verified. Provides 5 concrete invariant test patterns in `fv-invariant-pattern.ts` that work with `anchor test`.
- **Trade-off**: Judges without Solana toolchain see "SKIP" but also see the pattern files and documentation. SOLANA_LEARNERS get a working `anchor test` experience.
- **Lesson**: When a feature requires toolchain, provide both paths: (a) demonstration code that works without it (pattern files, docs), (b) documentation of what changes with toolchain installed. Best-effort beats absent.

## Future Improvements

- [ ] **Line-number drift check (Check 20)** — `rg -n "VULN-\d+"` in source and verify each finding's claimed line falls within its VULN function scope.
- [ ] **Flake8 config + lint CI** — pyproject.toml has black + mypy but no flake8.
- [ ] **Runtime tests** — Solana test validator in CI (~3 min extra per run).
- [ ] **Native qed-solana CI integration** — Needs toolchain install.
- [ ] **Interactive audit dashboard** — Visual report with severity distribution.
- [ ] **Multi-program audit aggregation** — Combine findings from multiple Anchor programs.
- [ ] **Visual diff** — Pre/post-fix audit report comparison.
